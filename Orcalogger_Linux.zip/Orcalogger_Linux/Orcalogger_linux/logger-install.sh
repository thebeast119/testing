wget -v https://artifacts.elastic.co/downloads/beats/filebeat/filebeat-7.14.2-amd64.deb
dpkg -i filebeat-7.14.2-amd64.deb

sleep 5
mkdir /etc/filebeat/certs
mv certs/* /etc/filebeat/certs/
mv utility/logger.yml /etc/filebeat

sleep 5
sudo systemctl enable filebeat
sudo mkdir -p /etc/systemd/system/filebeat.service.d

sleep 5
mv utility/override.conf /etc/systemd/system/filebeat.service.d/override.conf

sleep 5
sudo systemctl daemon-reload

sleep 5
sudo systemctl restart filebeat